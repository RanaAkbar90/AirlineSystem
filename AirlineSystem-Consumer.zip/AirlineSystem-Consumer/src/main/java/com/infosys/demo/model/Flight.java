package com.infosys.demo.model;

import java.io.Serializable;
import java.time.LocalDateTime;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="Flight")
public class Flight implements Serializable{
	
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="flightId")
	private Integer flightId;
	
	@Column(name="flightName")
	private String flightName;
	
	@Column(name="arrivalTime")
	private LocalDateTime arrivalTime;
		
	@Column(name="departureTime")
	private LocalDateTime departureTime;
	
	@Column(name="price")
	private double price;
	
	public Flight() {
		// TODO Auto-generated constructor stub
	}
		
	public Flight(Integer flightId, String flightName, LocalDateTime arrivalTime,double price, LocalDateTime departureTime) {
		super();
		this.flightId = flightId;
		this.flightName = flightName;
		this.arrivalTime = arrivalTime;
		this.departureTime = departureTime;
		this.price = price;
	}
	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	public Integer getFlightId() {
		return flightId;
	}
	public void setFlightId(Integer flightId) {
		this.flightId = flightId;
	}
	public String getFlightName() {
		return flightName;
	}
	public void setFlightName(String flightName) {
		this.flightName = flightName;
	}
	public LocalDateTime getArrivalTime() {
		return arrivalTime;
	}
	public void setArrivalTime(LocalDateTime arrivalTime) {
		this.arrivalTime = arrivalTime;
	}
	public LocalDateTime getDepartureTime() {
		return departureTime;
	}
	public void setDepartureTime(LocalDateTime departureTime) {
		this.departureTime = departureTime;
	}
	public double getPrice() {
		return price;
	}
	public void setPrice(double price) {
		this.price = price;
	}
	@Override
	public String toString() {
		return "Flight [flightId=" + flightId + ", flightName=" + flightName + ", arrivalTime=" + arrivalTime
				+ ", departureTime=" + departureTime + ", price=" + price + "]";
	}
	
}
