package com.infosys.demo.model;

import java.io.Serializable;
import java.time.LocalDateTime;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;

@Entity
public class Ticket implements Serializable{

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "ticketId")
	private int ticketId;

	@Column(name = "price")
	private double price;
	
	@Column(name = "travelDate")
	private LocalDateTime travelDate;
	
	@OneToOne
	private Passenger passenger;
	
	public Ticket() {
		// TODO Auto-generated constructor stub
	}

	public Ticket(int ticketId, double price, LocalDateTime travelDate, Passenger passenger) {
		super();
		this.ticketId = ticketId;
		this.price = price;
		this.travelDate = travelDate;
		this.passenger = passenger;
	}

	public int getTicketId() {
		return ticketId;
	}

	public void setTicketId(int ticketId) {
		this.ticketId = ticketId;
	}

	public double getPrice() {
		return price;
	}

	public void setPrice(double price) {
		this.price = price;
	}

	public LocalDateTime getTravelDate() {
		return travelDate;
	}

	public void setTravelDate(LocalDateTime travelDate) {
		this.travelDate = travelDate;
	}

	public Passenger getPassenger() {
		return passenger;
	}

	public void setPassenger(Passenger passenger) {
		this.passenger = passenger;
	}

	@Override
	public String toString() {
		return "Ticket [ticketId=" + ticketId + ", price=" + price + ", travelDate=" + travelDate + ", passenger="
				+ passenger + "]";
	}
}
