package com.infosys.demo.controller;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.infosys.demo.model.Flight;

@RestController
@RequestMapping("/booking")
public class OnlineAirticketBooking {

	@Autowired
	private RestTemplate temp;
	
	static final String URL="http://localhost:8083/airlineSystem";
	
	@GetMapping("/getDetails/{name}")
	public Flight fetchFlightDetails(@RequestParam("name") String name){
		return temp.getForObject(URL+"/getDetails/"+name, Flight.class);
	}
	
	@GetMapping("/search/{name}")
	public String searchFlight(@RequestParam("name") String name) {
		Flight flight=temp.getForObject(URL+"/getAll", Flight.class);
		if(flight.getFlightName().contains(name))
			return flight.getFlightName();
		else
			return "Please check the flight name...";
	}
	
	@GetMapping("/sortedFlightList")
	public List<Flight> sortedFlightList(){
		Flight flight=temp.getForObject(URL+"/getAll", Flight.class);
		List<Flight> list=new ArrayList<Flight>();
		list.add(flight);
		//Lambda expression for Comparator()
		list.sort((Flight f1, Flight f2)->f1.getArrivalTime().compareTo(f2.getArrivalTime()));
		return list;
		
	}
}
