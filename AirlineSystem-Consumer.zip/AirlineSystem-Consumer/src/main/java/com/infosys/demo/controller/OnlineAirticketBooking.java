package com.infosys.demo.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.infosys.demo.model.Flight;

@RestController
@RequestMapping("/booking")
public class OnlineAirticketBooking {

	@Autowired
	private RestTemplate temp;
	
	static final String URL="http://localhost:8083/airlineSystem";
	static final String result="Please check the flight name...";
	
	@GetMapping("/getDetails/{name}")
	public Flight fetchFlightDetails(@RequestParam("name") String name){
		return temp.getForObject(URL+"/getDetails/"+name, Flight.class);
	}
	
	@GetMapping("/search/{name}")
	public String searchFlight(@RequestParam("name") String name) {
		Flight flight=temp.getForObject(URL+"/getAll", Flight.class);
		if(flight.getFlightName().contains(name))
			return flight.getFlightName();
		else
			return result;
	}
	
	@GetMapping("/sortedFlightList")
	public List<Flight> sortedFlightList(){
		Flight flight=temp.getForObject(URL+"/getAll", Flight.class);
		List<Flight> list=new ArrayList<Flight>();
		list.add(flight);
		return list.stream().sorted().collect(Collectors.toList());
		
	}
}
