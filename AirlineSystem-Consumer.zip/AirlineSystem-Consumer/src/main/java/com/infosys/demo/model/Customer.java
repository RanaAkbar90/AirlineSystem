package com.infosys.demo.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;

@Entity
public class Customer implements Serializable{

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "custId")
	private int custId;

	@Column(name = "custDestination")
	private String custDestination;
	
	@OneToOne
	private Passenger passenger;

	public Customer() {
		// TODO Auto-generated constructor stub
	}
	
	public Customer(int custId, String custDestination, Passenger passenger) {
		super();
		this.custId = custId;
		this.custDestination = custDestination;
		this.passenger = passenger;
	}

	public int getCustId() {
		return custId;
	}

	public void setCustId(int custId) {
		this.custId = custId;
	}

	public String getCustDestination() {
		return custDestination;
	}

	public void setCustDestination(String custDestination) {
		this.custDestination = custDestination;
	}

	public Passenger getPassenger() {
		return passenger;
	}

	public void setPassenger(Passenger passenger) {
		this.passenger = passenger;
	}

	@Override
	public String toString() {
		return "Customer [custId=" + custId + ", custDestination=" + custDestination + ", passenger=" + passenger + "]";
	}	
}