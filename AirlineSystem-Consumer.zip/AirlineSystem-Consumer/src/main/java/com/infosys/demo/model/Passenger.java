package com.infosys.demo.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Inheritance;
import javax.persistence.InheritanceType;
import javax.persistence.OneToOne;

@Entity
public class Passenger implements Serializable{

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "passengerId")
	private int passengerId;

	@Column(name = "name")
	private String name;
	
	@Column(name = "mailId", unique=true)
	private String mailId;
	
	@Column(name = "mobile")
	private long mobile;
	
	@Column(name = "address")
	private String address; 
	
	@OneToOne
	private Customer cust;
	
	@OneToOne
	private Ticket ticket;
	
	public Passenger() {
		// TODO Auto-generated constructor stub
	}

	public Passenger(int passengerId, String name, String mailId, long mobile, String address, Customer cust,
			Ticket ticket) {
		super();
		this.passengerId = passengerId;
		this.name = name;
		this.mailId = mailId;
		this.mobile = mobile;
		this.address = address;
		this.cust = cust;
		this.ticket = ticket;
	}

	public int getPassengerId() {
		return passengerId;
	}

	public void setPassengerId(int passengerId) {
		this.passengerId = passengerId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getMailId() {
		return mailId;
	}

	public void setMailId(String mailId) {
		this.mailId = mailId;
	}

	public long getMobile() {
		return mobile;
	}

	public void setMobile(long mobile) {
		this.mobile = mobile;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public Customer getCust() {
		return cust;
	}

	public void setCust(Customer cust) {
		this.cust = cust;
	}

	public Ticket getTicket() {
		return ticket;
	}

	public void setTicket(Ticket ticket) {
		this.ticket = ticket;
	}

	@Override
	public String toString() {
		return "Passenger [passengerId=" + passengerId + ", name=" + name + ", mailId=" + mailId + ", mobile=" + mobile
				+ ", address=" + address + ", cust=" + cust + ", ticket=" + ticket + "]";
	}
}
