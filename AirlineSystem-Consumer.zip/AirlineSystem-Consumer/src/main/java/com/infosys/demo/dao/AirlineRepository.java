package com.infosys.demo.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.infosys.demo.model.Ticket;

public interface AirlineRepository extends JpaRepository<Ticket, Integer> {

}
