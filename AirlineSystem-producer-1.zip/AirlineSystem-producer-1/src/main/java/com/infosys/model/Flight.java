package com.infosys.model;

import java.io.Serializable;
import java.time.LocalDateTime;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.PrimaryKeyJoinColumn;
import javax.persistence.Table;

@Entity
@Table(name="Flight")
public class Flight implements Serializable{
	
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="flightId")
	private Integer flightId;
	
	@Column(name="flightName")
	private String flightName;
	
	@Column(name="arrivalTime")
	private LocalDateTime arrivalTime;
		
	@Column(name="departureTime")
	private LocalDateTime departureTime;
	
	@Column(name="price")
	private double price;
	
	@OneToMany
	private List<Seats> seat;
	
	@ManyToOne
	private Airport airport;
	
	@OneToOne
	private AirlineCompany company;
	
	public Flight() {
		// TODO Auto-generated constructor stub
	}
		
	public Flight(Integer flightId, String flightName, LocalDateTime arrivalTime, LocalDateTime departureTime,
			double price, List<Seats> seat, Airport airport, AirlineCompany company) {
		super();
		this.flightId = flightId;
		this.flightName = flightName;
		this.arrivalTime = arrivalTime;
		this.departureTime = departureTime;
		this.price = price;
		this.seat = seat;
		this.airport = airport;
		this.company = company;
	}


	public List<Seats> getSeat() {
		return seat;
	}

	public void setSeat(List<Seats> seat) {
		this.seat = seat;
	}

	public Airport getAirport() {
		return airport;
	}

	public void setAirport(Airport airport) {
		this.airport = airport;
	}

	public AirlineCompany getCompany() {
		return company;
	}

	public void setCompany(AirlineCompany company) {
		this.company = company;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	public Integer getFlightId() {
		return flightId;
	}
	public void setFlightId(Integer flightId) {
		this.flightId = flightId;
	}
	public String getFlightName() {
		return flightName;
	}
	public void setFlightName(String flightName) {
		this.flightName = flightName;
	}
	public LocalDateTime getArrivalTime() {
		return arrivalTime;
	}
	public void setArrivalTime(LocalDateTime arrivalTime) {
		this.arrivalTime = arrivalTime;
	}
	public LocalDateTime getDepartureTime() {
		return departureTime;
	}
	public void setDepartureTime(LocalDateTime departureTime) {
		this.departureTime = departureTime;
	}
	public double getPrice() {
		return price;
	}
	public void setPrice(double price) {
		this.price = price;
	}
	@Override
	public String toString() {
		return "Flight [flightId=" + flightId + ", flightName=" + flightName + ", arrivalTime=" + arrivalTime
				+ ", departureTime=" + departureTime + ", price=" + price + "]";
	}
	
}
