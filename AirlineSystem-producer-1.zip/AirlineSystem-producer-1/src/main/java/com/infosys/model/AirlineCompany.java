package com.infosys.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name="airlineCompany")
public class AirlineCompany implements Serializable{
	
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="compnyId")
	private int companyId;
	
	@Column(name="companyName")
	private String companyName;
	
	@OneToOne
	private Flight flight;
	
	public AirlineCompany(int companyId, String companyName, Flight flight) {
		super();
		this.companyId = companyId;
		this.companyName = companyName;
		this.flight = flight;
	}

	public AirlineCompany() {
		// TODO Auto-generated constructor stub
	}
	
	public int getCompanyId() {
		return companyId;
	}

	public void setCompanyId(int companyId) {
		this.companyId = companyId;
	}

	public String getCompanyName() {
		return companyName;
	}

	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}

	public Flight getFlight() {
		return flight;
	}

	public void setFlight(Flight flight) {
		this.flight = flight;
	}

	@Override
	public String toString() {
		return "AirlineCompany [companyId=" + companyId + ", companyName=" + companyName + "]";
	}
	
	

}
