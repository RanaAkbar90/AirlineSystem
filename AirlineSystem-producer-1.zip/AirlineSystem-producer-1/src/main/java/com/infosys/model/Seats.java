package com.infosys.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Inheritance;
import javax.persistence.InheritanceType;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name = "Seats")
public class Seats implements Serializable {

	private static final long serialVersionUID = 5685990689947599910L;

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "seatId")
	private int seatId;

	@Column(name = "totalSeats")
	private long totalSeats;

	@Column(name = "bookedSeats")
	private long bookedSeats;
	
	@Column(name="availableSeats")
	private long availableSeats;

	@ManyToOne
	private Flight flight;

	public Seats() {

	}

	public Seats(int seatId, long totalSeats, long bookedSeats,long availableSeats, Flight flight) {
		super();
		this.seatId = seatId;
		this.totalSeats = totalSeats;
		this.bookedSeats = bookedSeats;
		this.flight = flight;
		this.availableSeats=availableSeats;
	}

	public int getSeatId() {
		return seatId;
	}

	public void setSeatId(int seatId) {
		this.seatId = seatId;
	}

	public long getTotalSeats() {
		return totalSeats;
	}

	public void setTotalSeats(long totalSeats) {
		this.totalSeats = totalSeats;
	}

	public long getBookedSeats() {
		return bookedSeats;
	}

	public void setBookedSeats(long bookedSeats) {
		this.bookedSeats = bookedSeats;
	}

	public Flight getFlight() {
		return flight;
	}

	public void setFlight(Flight flight) {
		this.flight = flight;
	}

	public long getAvailableSeats() {
		return availableSeats;
	}

	public void setAvailableSeats(long availableSeats) {
		this.availableSeats = availableSeats;
	}

	@Override
	public String toString() {
		return "Seats [seatId=" + seatId + ", totalSeats=" + totalSeats + ", bookedSeats=" + bookedSeats + "]";
	}
}
