package com.infosys.controller;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.infosys.dao.FlightRepository;
import com.infosys.dao.SeatsRepository;
import com.infosys.model.Flight;
import com.infosys.model.Seats;

@RestController
@RequestMapping("/airlineSystem")
public class AirlineSystem {

	@Autowired
	private FlightRepository flightRepo;

	@Autowired
	private SeatsRepository seatsRepo;

	@PostMapping("/addFDetails")
	public Flight addFlightDetails(@RequestBody Flight flight) {

		return flightRepo.save(flight);
	}

	@GetMapping("/getScheduledFlight")
	public List<Flight> getAllScheduledFlight() {
		
		//use of stream and filter
		return flightRepo.findAll().stream().filter(s -> s.getArrivalTime().isAfter(LocalDateTime.now()))
				.collect(Collectors.toList());
	}

	@GetMapping("/getStatus/{flightName}")
	public boolean getStatusOfScheduledFlight(@RequestParam("flightName") String flightName) {
		Flight flight = flightRepo.findByFlightName(flightName);
		//use of DateAndTime api
		if (flight.getArrivalTime().isAfter(LocalDateTime.now())) {
			return true;
		} else {
			return false;
		}

	}

	@GetMapping("/getSeats/{id}")
	public long getAvailableSeatsOfFlight(@RequestParam("id") Integer id) {
		//use of optional
		Optional<Flight> flight = flightRepo.findById(id);
		Optional<Seats> seat = flight.map(flt -> seatsRepo.findOne(flt));
		seat.ifPresent(sts -> {
			long total = sts.getTotalSeats();
			long booked = sts.getBookedSeats();
			long available = total - booked;
			System.out.println("Available Seats" + available);
			new Seats().setAvailableSeats(available);
		});
		return new Seats().getAvailableSeats();
	}

	@GetMapping("/getDetails/{name}")
	public Flight getFlightDetails(@RequestParam("name") String name) {
		return flightRepo.findByFlightName(name);
	}

	@GetMapping("/getAll")
	public List<Flight> getAllFlight() {
		return flightRepo.findAll();
	}

}
