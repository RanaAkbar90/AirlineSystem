package com.infosys.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.infosys.model.Flight;
import com.infosys.model.Seats;

@Repository
public interface SeatsRepository extends JpaRepository<Seats, Integer> {

	public Seats findOne(Flight flt);

}
